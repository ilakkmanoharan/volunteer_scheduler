#!/usr/bin/env bash

npm run start
